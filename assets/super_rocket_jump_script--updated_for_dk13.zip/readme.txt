This is a script written a long time ago for Daikatana that allows you to do 
super rocket jumps and super shotcycler jumps.  The original author is unknown.

When we introduced async rendering to Daikatana 1.3 it broke the script unless
cl_async was disabled.  This is an update to the original script to co-exist
peacefully with cl_async being enabled.

Just put this in your Daikatana\data directory and exec srj.cfg in console or add
exec "srj.cfg" to your autoexec.cfg.

Default binding is 'z' key.  Change it in srj.cfg if that bothers you.


Enjoy!
[HCI]Mara'akate
