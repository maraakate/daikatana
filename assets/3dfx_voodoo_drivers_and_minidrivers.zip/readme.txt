Drivers tested on Daikatana v1.3 for 3DFX Voodoo.
+-----------------------------+
|     Table of Contents       |
|                             |
|  1 - Instructions           |
|  2 - Additional Tweaks      |
|  3 - Contact                |
+-----------------------------+

1 - Instructions
---------------------------------------------------------
Windows 9x: If you already have AmigaMerlin v2.9 on your Voodoo 3/4/5
or FastVoodoo v4.6 on your Voodoo 2 then skip the first step.

Windows 2K/XP: If you already have AmigaMerlin v3.1 R11 on your Voodoo3/4/5
or FastVoodoo v4.0 XP Gold Edition then skip the first step.

Windows XP 64-bit, Windows Vista and later versions of Windows are untested.
If you know of drivers that reliably work on these platforms then let us know.

1) Install the proper driver for your card in /drivers.  Using other 3rd
   party drivers may cause problems, but if they work for you then
   let us know.
2) Pick a driver, WickedGL is the fastest at the expense of some image quality
   to use it rename one of the following files in /wickedgl to opengl32.dll:

   * opengl32.ban - WickedGL for Voodoo Banshee
   * opengl32.v23 - WickedGL for Voodoo 2/3
   * opengl32.v5  - WickedGL for Voodoo 4/5
   * ogl_hres.ban - WickedGL for Voodoo Banshee in 1024x768 and higher modes.
   * ogl_hres.v23 - WickedGL for Voodoo 2/3 in 1024x768 and higher modes.
   * ogl_hres.v5  - WickedGL for Voodoo 4/5 in 1024x768 and higher modes.

   WGL_CTRL.EXE is a utility for fine tuning some options with WickedGL.
   It's recommended to leave the settings at default values, but feel free
   to experiment.

   Mesa includes v6.2 and v6.31.  Mesa v6.31 is OK, but the lighting
   engine was upgraded.  If you get extreme slowdowns with dynamic lights
   and your not on a Pentium 1 try Mesa v6.2.  Mesa v6.31 is included by
   default in AmigaMerlin v3.1 R11 for Win2k/XP so it's unnecessary to copy
   it over.

3) If you want some additional performance tweaks you can run 3dfx.bat from
   a command prompt and start daikatana from the same command prompt.  If
   you want to permanently merge the environment vars in then add them to
   your autoexec.bat.

Voodoo 1, Rush and Banshee are untested and performance is assumed to be bad.

2 - Additional Tweaks
---------------------------------------------------------
* gl_maxparticles - Set this somewhere in the neighborhood of 500-1000 to
                    cap the maximum number of particles rendered per frame.
* gl_ext_palettedtexture - This is the equivalent of the "8-bit" option in
                           Quake 2.  Set this to 0 to disable palette sharing
                           in textures.  This may improve performance and
                           image quality at the expense of texture memory.
                           Should be OK Voodoo 5.
* cl_particles_blood_reduced - Set this to 1 to reduce the particle complexity
                               of blood puffs/clouds.
* gl_dynamic - Set to 0 to disable dynamic lights.
* gl_flashblend - Set to 1 to enable a fake dynamic lighting effect.  Useful
                  if gl_dynamic is disabled.
* gl_texturemode - Make sure this is GL_LINEAR_MIPMAP_NEAREST for bilinear
                   filtering.  Otherwise, GL_LINEAR_MIPMAP_LINEAR is for
                   trilinear filtering.  Bilinear is faster at the expense
                   of some image quality.
* Voodoo 2 may require reduced texture quality in the Video options menu
  if you experience texture thrashing.

3 - Contact
---------------------------------------------------------
If you're having problems or have found another driver that you think performs
as well or better than the ones provided please lets us know on the Daikatana
Issue tracker: https://bitbucket.org/daikatana13/daikatana/issues/new
