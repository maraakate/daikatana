These are the subtitlies packaged with v1.2 english.  This is to help
translators.  Extract to data/ directory and start editing. :)

If you are ready to submit your changes or have questions please leave
a post on the Issue tracker (https://bitbucket.org/daikatana13/daikatana/issues)
or email me at emoaddict15@gmail.com.

Thanks and good luck!
Mara'akate
