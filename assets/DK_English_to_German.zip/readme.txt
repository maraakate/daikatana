Pak44.pak is a comparision of the files that differ from pak1.pak from
the common English version versus the German copy.

Pak45.pak is the robot skins for humans.


To convert your copy of DK to the German version:

1) Rename/backup/remove/overwrite your Sounds directory.
   The game reads the characters voices from the data/Sounds directory so
   we are unable to place the translated sound files in a pak file because
   data/Sounds will take priority as external files.
   
   You can choose to overwrite the existing sound files or rename/backup or
   even remove the existing data/Sounds directory.
   
2) Copy pak44.pak to your data/ directory.  This file contains the different fonts,
   skin files, and other oddities that differ.

3) Pak45.pak is the robotic skins for humans.  It is up to you if you want to use this.
   
4) Run the game!  Be sure to set the language to "German" in the options menu!


Thanks!
[HCI]Mara'akate
