Daikatana Server Browser v0.1d -- Based on Gloom Server Browser by r1ch

Extract to your Daikatana directory and run.

Known bugs and issues:
* Ping icons are not transparent like other icons.
* IP addresses column has no sorting.

Any questions, comments, concerns?  Visit http://maraakate.org
or find us at irc://irc.oftc.net/#daikatana.
