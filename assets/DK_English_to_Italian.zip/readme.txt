This pak44.pak is a comparision of the files that differ from pak1.pak from
the common English version versus the Italian copy.

To convert your copy of DK to the Italian version:

1) Rename/backup/remove/overwrite your Sounds directory.
   The game reads the characters voices from the data/Sounds directory so
   we are unable to place the translated sound files in a pak file because
   data/Sounds will take priority as external files.
   
   You can choose to overwrite the existing sound files or rename/backup or
   even remove the existing data/Sounds directory.
   
2) Copy pak44.pak to your data/ directory.  This file contains the different fonts,
   skin files, and other oddities that differ.
   
3) Run the game!


Please note that the internal game text like pickup messages, the HUD, etc are
not translated.  We can compile Italian builds with this in them.  If you are
using this and would like the updated builds with translated in-game text
please create an issue report on the DK 1.3 bug tracker located at:

https://bitbucket.org/daikatana13/daikatana/issues?status=new&status=open

Thanks!
[HCI]Mara'akate
