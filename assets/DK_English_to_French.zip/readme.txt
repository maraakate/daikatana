This pak44.pak is a comparision of the files that differ from pak1.pak from
the common English version versus the French copy.

To convert your copy of DK to the French version:

1) Rename/backup/remove/overwrite your Sounds directory.
   The game reads the characters voices from the data/Sounds directory so
   we are unable to place the translated sound files in a pak file because
   data/Sounds will take priority as external files.
   
   You can choose to overwrite the existing sound files or rename/backup or
   even remove the existing data/Sounds directory.
   
2) Copy pak44.pak to your data/ directory.  This file contains the different fonts,
   skin files, and other oddities that differ.
   
3) Run the game!  Be sure to set the language to "French" in the options menu!


Thanks!
[HCI]Mara'akate
